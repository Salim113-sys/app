import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:daily_reset/theme.dart';
import 'package:daily_reset/providers/habit_provider.dart';
import 'package:daily_reset/providers/daily_log_provider.dart';
import 'package:daily_reset/models/program_pack.dart';
import 'package:daily_reset/providers/hydration_provider.dart';
import 'package:daily_reset/providers/workout_provider.dart';
import 'package:daily_reset/widgets/stat_card.dart';
import 'package:daily_reset/widgets/mood_trend_chart.dart';
import 'package:daily_reset/widgets/empty_state.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final habitProvider = context.watch<HabitProvider>();
    final logProvider = context.watch<DailyLogProvider>();
    final hydrationProvider = context.watch<HydrationProvider>();
    final workoutProvider = context.watch<WorkoutProvider>();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Your Progress',
          style: context.textStyles.headlineSmall?.semiBold,
        ),
      ),
      body: habitProvider.habits.isEmpty
          ? const EmptyState(
              icon: Icons.show_chart,
              title: 'No stats yet',
              description: 'Add habits and track your progress to see stats!',
            )
          : SingleChildScrollView(
              padding: AppSpacing.paddingLg,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Mood Trend (Last 7 Days)',
                    style: context.textStyles.titleLarge?.semiBold,
                  ),
                  const SizedBox(height: AppSpacing.md),
                  MoodTrendChart(moods: logProvider.getLast7DaysMoods()),
                  const SizedBox(height: AppSpacing.xl),
                  Text(
                    'Habit Streaks',
                    style: context.textStyles.titleLarge?.semiBold,
                  ),
                  const SizedBox(height: AppSpacing.md),
                  ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: habitProvider.habits.length,
                    separatorBuilder: (_, __) => const SizedBox(height: AppSpacing.sm),
                    itemBuilder: (context, index) {
                      final habit = habitProvider.habits[index];
                      return FutureBuilder<int>(
                        future: logProvider.getHabitStreak(habit.id),
                        builder: (context, streakSnapshot) {
                          return FutureBuilder<double>(
                            future: logProvider.getWeeklyCompletionRate(habit.id),
                            builder: (context, rateSnapshot) {
                              final streak = streakSnapshot.data ?? 0;
                              final rate = rateSnapshot.data ?? 0.0;
                              return StatCard(
                                habit: habit,
                                streak: streak,
                                weeklyCompletion: rate,
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                  const SizedBox(height: AppSpacing.xl),
                  if (hydrationProvider.isInitialized) ...[
                    Text(
                      'Hydration (Last 7 Days)',
                      style: context.textStyles.titleLarge?.semiBold,
                    ),
                    const SizedBox(height: AppSpacing.md),
                    _HydrationStatsSection(hydrationProvider: hydrationProvider),
                    const SizedBox(height: AppSpacing.xl),
                  ],
                  _WorkoutStatsSection(workoutProvider: workoutProvider),
                  const SizedBox(height: AppSpacing.xl),
                   Text(
                     'By program',
                     style: context.textStyles.titleLarge?.semiBold,
                   ),
                   const SizedBox(height: AppSpacing.md),
                   _ProgramStatsSection(
                     habitProvider: habitProvider,
                     logProvider: logProvider,
                   ),
                   const SizedBox(height: AppSpacing.xl),
                  Container(
                    padding: AppSpacing.paddingMd,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(AppRadius.md),
                      border: Border.all(
                        color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.info_outline,
                          color: Theme.of(context).colorScheme.primary,
                          size: 20,
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: Text(
                            'AdMob Banner Ad Placeholder\n(Integrate ads here for monetization)',
                            style: context.textStyles.bodySmall?.withColor(
                              Theme.of(context).colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.lg),
                ],
              ),
            ),
    );
  }
}

class _ProgramStatsSection extends StatelessWidget {
  final HabitProvider habitProvider;
  final DailyLogProvider logProvider;

  const _ProgramStatsSection({
    required this.habitProvider,
    required this.logProvider,
  });

  @override
  Widget build(BuildContext context) {
    final packs = ProgramPacksRepository.defaultPacks;

    // Build aggregates per pack using existing provider helpers.
    final List<_ProgramAggregate> aggregates = [];
    for (final pack in packs) {
      // Collect habit IDs that belong to this program.
      final habitIds = habitProvider.habits
          .where((h) => h.programId == pack.id)
          .map((h) => h.id)
          .toList();

      if (habitIds.isEmpty) continue;

      final (activeDays, totalDays) =
          logProvider.getProgramActivityForLastDays(habitIds, days: 7);
      final streak = logProvider.getProgramStreak(habitIds);

      if (activeDays == 0 && streak == 0) {
        // No meaningful activity for this program yet; skip.
        continue;
      }

      aggregates.add(
        _ProgramAggregate(
          pack: pack,
          activeDays: activeDays,
          totalDays: totalDays,
          streak: streak,
        ),
      );
    }

    if (aggregates.isEmpty) {
      return Text(
        'No program activity yet. Try completing some habits.',
        style: context.textStyles.bodyMedium?.withColor(
          Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      );
    }

    aggregates.sort((a, b) => b.activeDays.compareTo(a.activeDays));

    return Column(
      children: [
        for (final agg in aggregates) ...[
          _ProgramStatTile(aggregate: agg),
          const SizedBox(height: AppSpacing.sm),
        ],
      ],
    );
  }
}

class _ProgramAggregate {
  final ProgramPack pack;
  final int activeDays;
  final int totalDays;
  final int streak;

  _ProgramAggregate({
    required this.pack,
    required this.activeDays,
    required this.totalDays,
    required this.streak,
  });
}

class _ProgramStatTile extends StatelessWidget {
  final _ProgramAggregate aggregate;

  const _ProgramStatTile({
    required this.aggregate,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final daysCount = aggregate.activeDays;
    final totalDays = aggregate.totalDays == 0 ? 7 : aggregate.totalDays;
    final intensity = daysCount / (totalDays == 0 ? 1 : totalDays);

    return Container(
      padding: AppSpacing.paddingMd,
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.3),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            _iconForPack(aggregate.pack.iconKey),
            color: theme.colorScheme.primary,
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  aggregate.pack.name,
                  style: context.textStyles.titleMedium?.semiBold,
                ),
                const SizedBox(height: 4),
                Text(
                  '$daysCount of $totalDays days with activity',
                  style: context.textStyles.bodySmall?.withColor(
                    theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Current streak: ${aggregate.streak} days',
                  style: context.textStyles.bodySmall?.withColor(
                    theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.md),
          Column(
            children: [
              Text(
                'Intensity',
                style: context.textStyles.labelSmall?.withColor(
                  theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 4),
              SizedBox(
                width: 56,
                child: LinearProgressIndicator(
                  value: intensity.clamp(0, 1),
                  backgroundColor: theme.colorScheme.surface,
                  color: theme.colorScheme.primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

IconData _iconForPack(String iconKey) {
  switch (iconKey) {
    case 'water':
      return Icons.local_drink_outlined;
    case 'walk':
      return Icons.directions_walk_outlined;
    case 'focus':
      return Icons.center_focus_strong;
    case 'workout':
      return Icons.fitness_center;
    case 'general':
    default:
      return Icons.auto_awesome_outlined;
  }
}

class _HydrationStatsSection extends StatefulWidget {
  final HydrationProvider hydrationProvider;

  const _HydrationStatsSection({required this.hydrationProvider});

  @override
  State<_HydrationStatsSection> createState() => _HydrationStatsSectionState();
}

class _HydrationStatsSectionState extends State<_HydrationStatsSection> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = widget.hydrationProvider.getLast7DayTotals();
  }

  @override
  Widget build(BuildContext context) {
    final settings = widget.hydrationProvider.settings;
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _future,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(AppSpacing.md),
              child: CircularProgressIndicator(),
            ),
          );
        }
        final data = snapshot.data!;
        int goalHits = 0;
        for (final day in data) {
          final total = day['totalMl'] as int? ?? 0;
          if (total >= settings.dailyGoalMl) {
            goalHits++;
          }
        }

        return Container(
          padding: AppSpacing.paddingMd,
          decoration: BoxDecoration(
            color: Theme.of(context)
                .colorScheme
                .surfaceContainerHighest
                .withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(
              color:
                  Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 80,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    for (final day in data)
                      Expanded(
                        child: _HydrationBar(
                          date: day['date'] as DateTime,
                          totalMl: day['totalMl'] as int? ?? 0,
                          goalMl: settings.dailyGoalMl,
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.sm),
              Text(
                'You hit your hydration goal $goalHits days in the last 7 days',
                style: context.textStyles.bodySmall?.withColor(
                  Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _HydrationBar extends StatelessWidget {
  final DateTime date;
  final int totalMl;
  final int goalMl;

  const _HydrationBar({
    required this.date,
    required this.totalMl,
    required this.goalMl,
  });

  @override
  Widget build(BuildContext context) {
    final ratio = goalMl <= 0 ? 0.0 : (totalMl / goalMl).clamp(0.0, 1.2);
    final theme = Theme.of(context);
    final label = ['M', 'T', 'W', 'T', 'F', 'S', 'S'][date.weekday - 1];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2),
      child: Column(
        children: [
          Expanded(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 400),
                curve: Curves.easeOut,
                width: 10,
                height: 60 * ratio,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(999),
                  color: ratio >= 1
                      ? theme.colorScheme.primary
                      : theme.colorScheme.primary.withValues(alpha: 0.5),
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: context.textStyles.labelSmall,
          ),
        ],
      ),
    );
  }
}

class _WorkoutStatsSection extends StatelessWidget {
  final WorkoutProvider workoutProvider;

  const _WorkoutStatsSection({required this.workoutProvider});

  @override
  Widget build(BuildContext context) {
    final (totalMinutes, activeDays) = workoutProvider.getLast7DaysTotals();
    final summary = workoutProvider.getLast7DaysSummary();

    if (summary.isEmpty && totalMinutes == 0) {
      return Container();
    }

    final theme = Theme.of(context);

    return Container(
      padding: AppSpacing.paddingMd,
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Workout (Last 7 Days)',
            style: context.textStyles.titleLarge?.semiBold,
          ),
          const SizedBox(height: AppSpacing.sm),
          SizedBox(
            height: 80,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final day in summary)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: Column(
                        children: [
                          Expanded(
                            child: Align(
                              alignment: Alignment.bottomCenter,
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 400),
                                curve: Curves.easeOut,
                                width: 10,
                                height: 60 *
                                    ((day['totalMinutes'] as int? ?? 0) / 30)
                                        .clamp(0.0, 1.2),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(999),
                                  color: (day['hasSession'] as bool? ?? false)
                                      ? theme.colorScheme.primary
                                      : theme.colorScheme.primary
                                          .withValues(alpha: 0.4),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            ['M', 'T', 'W', 'T', 'F', 'S', 'S']
                                [(day['date'] as DateTime).weekday - 1],
                            style: context.textStyles.labelSmall,
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            'You worked out $activeDays days • $totalMinutes min total',
            style: context.textStyles.bodySmall?.withColor(
              theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

