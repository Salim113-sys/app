import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'package:daily_reset/theme.dart';
import 'package:daily_reset/providers/theme_provider.dart';
import 'package:daily_reset/providers/habit_provider.dart';
import 'package:daily_reset/providers/daily_log_provider.dart';
import 'package:daily_reset/services/storage_service.dart';
import 'package:daily_reset/services/notification_service.dart';
import 'package:go_router/go_router.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = context.watch<ThemeProvider>();
    final notif = context.watch<NotificationService>();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Settings',
          style: context.textStyles.headlineSmall?.semiBold,
        ),
      ),
      body: SingleChildScrollView(
        padding: AppSpacing.paddingLg,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Appearance',
              style: context.textStyles.titleMedium?.semiBold.withColor(
                Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Card(
              child: SwitchListTile(
                title: const Text('Dark Mode'),
                subtitle: Text(
                  themeProvider.isDarkMode ? 'Enabled' : 'Disabled',
                ),
                secondary: Icon(
                  themeProvider.isDarkMode
                      ? Icons.dark_mode
                      : Icons.light_mode,
                  color: Theme.of(context).colorScheme.primary,
                ),
                value: themeProvider.isDarkMode,
                onChanged: (_) {
                  // Toggle theme mode in place without leaving the Settings screen.
                  // ThemeProvider notifies listeners, causing widgets to rebuild with new ThemeMode.
                  themeProvider.toggleTheme();
                },
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            Text(
              'Data Management',
              style: context.textStyles.titleMedium?.semiBold.withColor(
                Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Card(
              child: ListTile(
                leading: Icon(
                  Icons.delete_forever,
                  color: Theme.of(context).colorScheme.error,
                ),
                title: const Text('Reset All Data'),
                subtitle: const Text('Clear all habits and logs'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showResetDataDialog(context),
              ),
            ),
            const SizedBox(height: AppSpacing.sm),
            // Temporary testing helper for local notifications
            Card(
              child: ListTile(
                leading: Icon(Icons.notification_add_outlined,
                    color: Theme.of(context).colorScheme.primary),
                title: const Text('Test notification in 1 minute'),
                subtitle: const Text('Schedules a one-time test notification'),
                onTap: () async {
                  try {
                    await notif.scheduleOneTimeTestNotificationInOneMinute();
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Test notification scheduled for 1 minute from now')),
                      );
                    }
                  } catch (e) {
                    debugPrint('Test notification error: $e');
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Failed to schedule test notification: $e'),
                          backgroundColor: Theme.of(context).colorScheme.error,
                        ),
                      );
                    }
                  }
                },
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            Text(
              'Legal',
              style: context.textStyles.titleMedium?.semiBold.withColor(
                Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Card(
              child: ListTile(
                leading: Icon(
                  Icons.privacy_tip_outlined,
                  color: Theme.of(context).colorScheme.primary,
                ),
                title: const Text('Privacy Policy'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push('/privacy'),
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            Text(
              'About',
              style: context.textStyles.titleMedium?.semiBold.withColor(
                Theme.of(context).colorScheme.primary,
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Card(
              child: Padding(
                padding: AppSpacing.paddingMd,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Daily Reset',
                      style: context.textStyles.titleLarge?.bold,
                    ),
                    const SizedBox(height: AppSpacing.xs),
                    Text(
                      'Version 1.0.0',
                      style: context.textStyles.bodyMedium?.withColor(
                        Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(
                      'Build better habits, track your mood, and reset each day with calm and focus.',
                      style: context.textStyles.bodySmall?.withColor(
                        Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: AppSpacing.xl),
            Container(
              padding: AppSpacing.paddingMd,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(AppRadius.md),
                border: Border.all(
                  color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.3),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline,
                    color: Theme.of(context).colorScheme.primary,
                    size: 20,
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Text(
                      'AdMob Banner Ad Placeholder\n(Integrate ads here for monetization)',
                      style: context.textStyles.bodySmall?.withColor(
                        Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
          ],
        ),
      ),
    );
  }

  Future<void> _showResetDataDialog(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reset All Data'),
        content: const Text(
          'This will permanently delete all your habits, mood logs, and progress. This action cannot be undone.\n\nAre you sure you want to continue?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
              foregroundColor: Theme.of(context).colorScheme.onError,
            ),
            child: const Text('Reset All Data'),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      try {
        final storage = await StorageService.getInstance();
        await storage.clear();
        
        if (context.mounted) {
          await context.read<HabitProvider>().loadHabits();
          await context.read<DailyLogProvider>().loadTodayLog();
          
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('All data has been reset')),
          );
        }
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error resetting data: $e'),
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
          );
        }
      }
    }
  }
}
