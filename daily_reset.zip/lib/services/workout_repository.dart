import 'dart:async';

import 'package:daily_reset/models/workout_models.dart';
import 'package:daily_reset/services/storage_service.dart';
import 'package:flutter/foundation.dart';

class WorkoutRepository {
  static const String _logsKey = 'workout_session_logs_v1';

  // Asset Constants
  static const String assetWarmupMarch = 'assets/workout/warmup_march.png';
  static const String assetBodyweightSquats = 'assets/workout/bodyweight_squats.png';
  static const String assetInclinePushups = 'assets/workout/incline_pushups.png';
  static const String assetPlankHold = 'assets/workout/plank_hold.png';
  static const String assetNeckRolls = 'assets/workout/neck_rolls.png';
  static const String assetCatCow = 'assets/workout/cat_cow.png';
  static const String assetHipCircles = 'assets/workout/hip_circles.png';
  static const String assetHighKnees = 'assets/workout/high_knees.png';
  static const String assetFastFeet = 'assets/workout/fast_feet.png';
  static const String assetChildsPose = 'assets/workout/childs_pose.png';
  static const String assetFigure4 = 'assets/workout/figure_4.png';
  static const String assetReverseLunges = 'assets/workout/reverse_lunges.png';
  static const String assetPushups = 'assets/workout/pushups.png';
  static const String assetDeadBug = 'assets/workout/dead_bug.png';

  final StorageService _storage;
  final List<WorkoutRoutine> _routines;
  final List<WorkoutStep> _steps;

  final StreamController<List<WorkoutSessionLog>> _logsController =
      StreamController<List<WorkoutSessionLog>>.broadcast();

  List<WorkoutSessionLog> _logs = [];

  WorkoutRepository._(this._storage, this._routines, this._steps);

  static Future<WorkoutRepository> create() async {
    final storage = await StorageService.getInstance();
    final repo = WorkoutRepository._(storage, _seedRoutines, _seedSteps);
    await repo._loadLogs();
    return repo;
  }

  List<WorkoutRoutine> get routines => List.unmodifiable(_routines);

  List<WorkoutStep> stepsForRoutine(String routineId) {
    return _steps.where((s) => s.routineId == routineId).toList();
  }

  Stream<List<WorkoutSessionLog>> get logsStream => _logsController.stream;

  List<WorkoutSessionLog> get logs => List.unmodifiable(_logs);

  Future<void> _loadLogs() async {
    try {
      final rawList = _storage.getJsonList(_logsKey);
      if (rawList == null) {
        _logs = [];
      } else {
        _logs = rawList
            .map((e) => WorkoutSessionLog.fromJson(e))
            .toList(growable: false);
      }
    } catch (e, st) {
      debugPrint('WorkoutRepository._loadLogs error: $e\n$st');
      _logs = [];
    }
    _logsController.add(_logs);
  }

  Future<void> addSessionLog(WorkoutSessionLog log) async {
    _logs = [..._logs, log];
    await _persist();
  }

  Future<void> _persist() async {
    try {
      await _storage.saveJsonList(
        _logsKey,
        _logs.map((e) => e.toJson()).toList(growable: false),
      );
    } catch (e, st) {
      debugPrint('WorkoutRepository._persist error: $e\n$st');
    }
    _logsController.add(_logs);
  }

  /// Returns list of maps with keys: date (DateTime), totalMinutes (int), hasSession (bool).
  List<Map<String, dynamic>> getLast7DaysSummary() {
    final today = DateTime.now();
    final start = DateTime(today.year, today.month, today.day)
        .subtract(const Duration(days: 6));

    final Map<DateTime, int> minutesPerDay = {};
    final Map<DateTime, bool> hasSessionPerDay = {};

    for (final log in _logs) {
      final day = DateTime(log.startTime.year, log.startTime.month, log.startTime.day);
      if (day.isBefore(start)) continue;
      minutesPerDay[day] = (minutesPerDay[day] ?? 0) + log.totalMinutes;
      hasSessionPerDay[day] = true;
    }

    final List<Map<String, dynamic>> result = [];
    for (int i = 0; i < 7; i++) {
      final date = start.add(Duration(days: i));
      result.add({
        'date': date,
        'totalMinutes': minutesPerDay[date] ?? 0,
        'hasSession': hasSessionPerDay[date] ?? false,
      });
    }
    return result;
  }

  (int totalMinutes, int activeDays) getLast7DaysTotals() {
    final data = getLast7DaysSummary();
    int totalMinutes = 0;
    int activeDays = 0;
    for (final day in data) {
      final minutes = day['totalMinutes'] as int? ?? 0;
      if (minutes > 0) activeDays++;
      totalMinutes += minutes;
    }
    return (totalMinutes, activeDays);
  }

  static List<WorkoutRoutine> get _seedRoutines => const [
        WorkoutRoutine(
          id: 'quick_full_body',
          name: 'Quick Full Body',
          description: 'A short, balanced routine to wake up your whole body.',
          difficulty: WorkoutDifficulty.beginner,
          goal: WorkoutGoal.strength,
          estimatedMinutes: 15,
          isFeatured: true,
          tags: ['full body', 'warmup'],
        ),
        WorkoutRoutine(
          id: 'mobility_reset',
          name: 'Mobility Reset',
          description: 'Gentle stretches to undo desk tension and improve mobility.',
          difficulty: WorkoutDifficulty.beginner,
          goal: WorkoutGoal.mobility,
          estimatedMinutes: 12,
          isFeatured: true,
          tags: ['stretch', 'desk'],
        ),
        WorkoutRoutine(
          id: 'cardio_boost',
          name: 'Cardio Boost',
          description: 'Interval-style cardio to raise your heart rate.',
          difficulty: WorkoutDifficulty.intermediate,
          goal: WorkoutGoal.cardio,
          estimatedMinutes: 20,
          tags: ['hiit', 'intervals'],
        ),
        WorkoutRoutine(
          id: 'evening_unwind',
          name: 'Evening Unwind',
          description: 'Slow, grounding movements to help you wind down.',
          difficulty: WorkoutDifficulty.beginner,
          goal: WorkoutGoal.relax,
          estimatedMinutes: 10,
          tags: ['relax', 'evening'],
        ),
        WorkoutRoutine(
          id: 'strength_focus',
          name: 'Strength Focus',
          description: 'Focused strength blocks for legs, core, and upper body.',
          difficulty: WorkoutDifficulty.advanced,
          goal: WorkoutGoal.strength,
          estimatedMinutes: 25,
          tags: ['strength'],
        ),
      ];

  static List<WorkoutStep> get _seedSteps {
    final List<WorkoutStep> steps = [];

    void add(
      String routineId,
      String title,
      String description, {
      int? seconds,
      int? reps,
      WorkoutStepType type = WorkoutStepType.timed,
      String? icon,
      String? assetPath,
      String? instructions,
      int? recommendedSeconds,
      int? recommendedReps,
      String? mediaUrl,
      WorkoutMediaType mediaType = WorkoutMediaType.image,
    }) {
      steps.add(WorkoutStep(
        routineId: routineId,
        title: title,
        description: description,
        durationSeconds: seconds,
        reps: reps,
        type: type,
        iconName: icon,
        mediaType: mediaUrl != null
            ? (mediaUrl.endsWith('.gif') ? WorkoutMediaType.gif : WorkoutMediaType.image)
            : (assetPath != null ? WorkoutMediaType.image : WorkoutMediaType.icon),
        mediaAsset: icon, // Keeping icon name in mediaAsset for backward compat
        mediaAssetPath: assetPath,
        mediaUrl: mediaUrl,
        instructions: instructions,
        recommendedSeconds: recommendedSeconds,
        recommendedReps: recommendedReps,
      ));
    }

    // 1. Quick Full Body (Balanced)
    add(
      'quick_full_body',
      'Warm-up March',
      'Light marching in place to get blood flowing.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'directions_walk',
      assetPath: assetWarmupMarch,
      mediaUrl: 'assets/workout/full_body/warm_up_march.gif',
      instructions:
          'Stand tall with feet hip-width apart. Lift one knee towards your chest while swinging the opposite arm. Alternate legs in a rhythmic marching motion. Keep your chest up and core engaged. Breathe naturally.',
    );
    add(
      'quick_full_body',
      'Bodyweight Squats',
      'Basic squat to engage legs and glutes.',
      reps: 12,
      recommendedReps: 12,
      type: WorkoutStepType.reps,
      icon: 'fitness_center',
      assetPath: assetBodyweightSquats,
      mediaUrl: 'assets/workout/full_body/squats.gif',
      instructions:
          'Stand with feet shoulder-width apart. Lower your hips back and down as if sitting in a chair. Keep your chest up and heels flat on the floor. Drive through your heels to return to standing. Inhale down, exhale up.',
    );
    add(
      'quick_full_body',
      'Incline Push-ups',
      'Upper body pushing movement using a support.',
      reps: 10,
      recommendedReps: 10,
      type: WorkoutStepType.reps,
      icon: 'push_pin',
      assetPath: assetInclinePushups,
      mediaUrl: 'assets/workout/full_body/incline_pushups.gif',
      instructions:
          'Place hands on a stable surface (wall, table, or sturdy chair) slightly wider than shoulder-width. Step feet back to form a straight line from head to heels. Lower your chest towards the surface, then push back up. Keep your core tight.',
    );
    add(
      'quick_full_body',
      'Reverse Lunges',
      'Unilateral leg exercise for balance and strength.',
      reps: 12,
      recommendedReps: 12,
      type: WorkoutStepType.reps,
      icon: 'directions_walk',
      assetPath: assetReverseLunges,
      mediaUrl: 'assets/workout/full_body/reverse_lunges.gif',
      instructions:
          'Stand tall. Step one foot back and lower your back knee towards the ground. Both knees should bend to approx 90 degrees. Push through the front heel to return to start. Alternate legs. Keep your torso upright.',
    );
    add(
      'quick_full_body',
      'Plank Hold',
      'Core stability hold.',
      seconds: 40,
      recommendedSeconds: 40,
      type: WorkoutStepType.timed,
      icon: 'shield',
      assetPath: assetPlankHold,
      mediaUrl: 'assets/workout/full_body/plank.gif',
      instructions:
          'Start on your forearms and toes (or knees). Keep your body in a straight line from head to heels/knees. Squeeze your glutes and engage your core (pull belly button to spine). Don\'t let your hips sag or pike up. Breathe steadily.',
    );

    // 2. Mobility Reset (Desk/Office Relief)
    add(
      'mobility_reset',
      'Neck Rolls',
      'Release tension in the neck and shoulders.',
      seconds: 45,
      recommendedSeconds: 45,
      type: WorkoutStepType.timed,
      icon: 'self_improvement',
      assetPath: assetNeckRolls,
      mediaUrl: 'assets/workout/mobility/neck_rolls.gif',
      instructions:
          'Sit or stand tall. Slowly drop your chin to your chest, then roll your right ear to your right shoulder, look up slightly, and roll left ear to left shoulder. Move slowly and avoid any sharp pain. Breathe deeply.',
    );
    add(
      'mobility_reset',
      'Cat-Cow',
      'Mobilize the spine.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'pets',
      assetPath: assetCatCow,
      mediaUrl: 'assets/workout/mobility/cat_cow.gif',
      instructions:
          'Start on hands and knees (tabletop position). Inhale as you drop your belly and lift your gaze (Cow). Exhale as you round your spine towards the ceiling and tuck your chin (Cat). Move with your breath.',
    );
    add(
      'mobility_reset',
      'Thoracic Rotations',
      'Open up the mid-back.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'accessibility_new',
      mediaUrl: 'assets/workout/mobility/thoracic_rotation.gif',
      instructions:
          'In tabletop position, place one hand behind your head. Rotate your elbow down towards your opposite wrist, then open up and point your elbow towards the ceiling. Follow the elbow with your gaze. Do 30s on one side, then switch.',
    );
    add(
      'mobility_reset',
      'Hip Circles',
      'Loosen up tight hips.',
      seconds: 45,
      recommendedSeconds: 45,
      type: WorkoutStepType.timed,
      icon: 'donut_large',
      assetPath: assetHipCircles,
      mediaUrl: 'assets/workout/mobility/hip_circles.gif',
      instructions:
          'Stand with feet wider than shoulder-width, hands on hips. Move your hips in large circles, pushing them forward, side, back, and side. Keep knees soft. Reverse direction halfway through.',
    );
    add(
      'mobility_reset',
      'Child\'s Pose',
      'Gentle lower back stretch.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'self_improvement',
      assetPath: assetChildsPose,
      mediaUrl: 'assets/workout/mobility/childs_pose.gif',
      instructions:
          'Kneel on the floor, touching big toes together and sitting on your heels. Separate your knees as wide as your hips. Lay your torso down between your thighs and extend arms forward. Rest your forehead on the floor and breathe deeply.',
    );

    // 3. Cardio Boost (HIIT-lite)
    add(
      'cardio_boost',
      'March in Place',
      'Warm up the body.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'directions_walk',
      assetPath: assetWarmupMarch,
      mediaUrl: 'assets/workout/cardio/march.gif',
      instructions:
          'Start marching in place. Pump your arms and lift your knees. Gradually increase your pace as you warm up.',
    );
    add(
      'cardio_boost',
      'Step Jacks',
      'Low impact jumping jacks.',
      seconds: 45,
      recommendedSeconds: 45,
      type: WorkoutStepType.timed,
      icon: 'directions_run',
      mediaUrl: 'assets/workout/cardio/step_jacks.gif',
      instructions:
          'Stand with feet together. Step right foot out to the side while raising arms overhead. Return to center. Step left foot out while raising arms. Move quickly and rhythmically.',
    );
    add(
      'cardio_boost',
      'High Knees',
      'Drive knees up to increase heart rate.',
      seconds: 30,
      recommendedSeconds: 30,
      type: WorkoutStepType.timed,
      icon: 'directions_run',
      assetPath: assetHighKnees,
      mediaUrl: 'assets/workout/cardio/high_knees.gif',
      instructions:
          'Run in place, driving your knees up towards your chest as high as possible. Keep your chest up and land softly on the balls of your feet. Go at your own pace.',
    );
    add(
      'cardio_boost',
      'Rest',
      'Catch your breath.',
      seconds: 30,
      recommendedSeconds: 30,
      type: WorkoutStepType.timed,
      icon: 'air',
      instructions:
          'Walk slowly in place. Inhale deeply through your nose, exhale slowly through your mouth. Prepare for the next interval.',
    );
    add(
      'cardio_boost',
      'Fast Feet',
      'Quick agility movement.',
      seconds: 30,
      recommendedSeconds: 30,
      type: WorkoutStepType.timed,
      icon: 'bolt',
      assetPath: assetFastFeet,
      mediaUrl: 'assets/workout/cardio/fast_feet.gif',
      instructions:
          'Stand with feet hip-width, knees bent in an athletic stance. Run your feet as fast as you can in place, staying on the balls of your feet. Keep your upper body relatively still.',
    );
    add(
      'cardio_boost',
      'Butt Kicks',
      'Active recovery movement.',
      seconds: 45,
      recommendedSeconds: 45,
      type: WorkoutStepType.timed,
      icon: 'directions_run',
      mediaUrl: 'assets/workout/cardio/butt_kicks.gif',
      instructions:
          'Jog in place, kicking your heels up towards your glutes. Keep your knees pointing down and chest up. Use your arms for balance.',
    );

    // 4. Evening Unwind (Relaxation)
    add(
      'evening_unwind',
      'Neck Stretch',
      'Release neck tension.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'self_improvement',
      assetPath: assetNeckRolls,
      mediaUrl: 'assets/workout/relax/neck_stretch.gif',
      instructions:
          'Gently tilt your right ear to your right shoulder. Use your right hand to apply very light pressure if comfortable. Hold for 30s. Switch to the left side.',
    );
    add(
      'evening_unwind',
      'Shoulder Rolls',
      'Relax the shoulders.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'self_improvement',
      mediaUrl: 'assets/workout/relax/shoulder_rolls.gif',
      instructions:
          'Sit or stand comfortably. Shrug your shoulders up towards your ears, then roll them back and down. Repeat slowly, focusing on releasing tension on the way down.',
    );
    add(
      'evening_unwind',
      'Seated Forward Fold',
      'Stretch the back and hamstrings.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'self_improvement',
      mediaUrl: 'assets/workout/relax/forward_fold.gif',
      instructions:
          'Sit on the floor with legs extended. Inhale to lengthen your spine, exhale to hinge at your hips and fold forward over your legs. Keep a slight bend in knees if needed. Relax your head and neck.',
    );
    add(
      'evening_unwind',
      'Figure-4 Stretch',
      'Hip opener.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'event_seat',
      assetPath: assetFigure4,
      mediaUrl: 'assets/workout/relax/figure_4.gif',
      instructions:
          'Lie on your back. Cross your right ankle over your left knee. Gently pull your left thigh towards you until you feel a stretch in the right hip. Hold for 30s, then switch sides.',
    );
    add(
      'evening_unwind',
      'Deep Breathing',
      'Calm the nervous system.',
      seconds: 60,
      recommendedSeconds: 60,
      type: WorkoutStepType.timed,
      icon: 'air',
      mediaUrl: 'assets/workout/relax/breathing.gif',
      instructions:
          'Sit or lie comfortably. Place one hand on your belly. Inhale slowly for 4 counts, feeling your belly rise. Exhale slowly for 6 counts. Focus entirely on your breath.',
    );

    // 5. Strength Focus (Advanced)
    add(
      'strength_focus',
      'Bodyweight Squats',
      'Lower body strength.',
      reps: 15,
      recommendedReps: 15,
      type: WorkoutStepType.reps,
      icon: 'fitness_center',
      assetPath: assetBodyweightSquats,
      mediaUrl: 'assets/workout/strength/squats.gif',
      instructions:
          'Stand feet shoulder-width. Hinge hips back and squat down until thighs are parallel to floor. Keep chest up and knees tracking over toes. Drive up through heels.',
    );
    add(
      'strength_focus',
      'Standard Push-ups',
      'Upper body strength.',
      reps: 10,
      recommendedReps: 10,
      type: WorkoutStepType.reps,
      icon: 'fitness_center',
      assetPath: assetPushups,
      mediaUrl: 'assets/workout/strength/pushups.gif',
      instructions:
          'Start in high plank. Lower chest to floor, keeping elbows at 45-degree angle to body. Push back up to start. Modify on knees if form breaks down.',
    );
    add(
      'strength_focus',
      'Alternating Lunges',
      'Leg strength and balance.',
      reps: 24, // 12 per leg
      recommendedReps: 24,
      type: WorkoutStepType.reps,
      icon: 'directions_walk',
      assetPath: assetReverseLunges,
      mediaUrl: 'assets/workout/strength/lunges.gif',
      instructions:
          'Step forward with one leg, lowering hips until both knees are at 90 degrees. Push off front foot to return to start. Alternate legs. Keep core tight and torso upright.',
    );
    add(
      'strength_focus',
      'Glute Bridges',
      'Posterior chain activation.',
      reps: 15,
      recommendedReps: 15,
      type: WorkoutStepType.reps,
      icon: 'accessibility_new',
      mediaUrl: 'assets/workout/strength/glute_bridge.gif',
      instructions:
          'Lie on back, knees bent, feet flat on floor. Drive through heels to lift hips towards ceiling. Squeeze glutes at top. Lower slowly. Do not arch lower back.',
    );
    add(
      'strength_focus',
      'Dead Bug',
      'Core stability.',
      reps: 16,
      recommendedReps: 16,
      type: WorkoutStepType.reps,
      icon: 'bug_report',
      assetPath: assetDeadBug,
      mediaUrl: 'assets/workout/strength/dead_bug.gif',
      instructions:
          'Lie on back, arms extended up, legs in tabletop. Lower opposite arm and leg towards floor without letting lower back arch off ground. Return to center. Switch sides.',
    );
    add(
      'strength_focus',
      'Wall Sit',
      'Isometric leg endurance.',
      seconds: 45,
      recommendedSeconds: 45,
      type: WorkoutStepType.timed,
      icon: 'event_seat',
      mediaUrl: 'assets/workout/strength/wall_sit.gif',
      instructions:
          'Lean back against a wall. Slide down until knees are at 90 degrees. Hold position. Keep weight in heels and back flat against wall. Breathe.',
    );

    return steps;
  }
}
