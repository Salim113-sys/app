import 'dart:math';

import 'package:daily_reset/models/habit.dart';
import 'package:daily_reset/models/deep_work_settings.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

/// NotificationService centralizes all local notification logic.
///
/// Where it lives:
///  - File: lib/services/notification_service.dart
///
/// How it uses reminder fields:
///  - Habit.reminderTimeMinutes stores the time of day (minutes after midnight). If null => no reminders.
///  - Habit.reminderDays stores DateTime.weekday values (1=Mon..7=Sun). If null => days auto-derived from targetDaysPerWeek.
///  - When a habit is saved or updated, we cancel existing schedules for that habit and schedule new ones per day/time.
class NotificationService {
  NotificationService();

  static const String _androidChannelId = 'daily_reset_reminders';
  static const String _androidChannelName = 'Habit Reminders';
  static const String _androidChannelDesc = 'Daily/weekly habit reminder notifications';

  static const String _androidHydrationChannelId = 'daily_reset_hydration';
  static const String _androidHydrationChannelName = 'Hydration Reminders';
  static const String _androidHydrationChannelDesc =
      'Gentle reminders to keep you hydrated throughout the day';

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    try {
      // Timezone setup
      tz.initializeTimeZones();
      final dynamic result = await FlutterTimezone.getLocalTimezone();
      final String timeZoneName = (result is String) ? result : result.name;
      tz.setLocalLocation(tz.getLocation(timeZoneName));

      const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
      const initSettings = InitializationSettings(android: androidInit);
      await _plugin.initialize(initSettings);

       // Create Android channels
      const androidChannel = AndroidNotificationChannel(
        _androidChannelId,
        _androidChannelName,
        description: _androidChannelDesc,
        importance: Importance.high,
      );
      const hydrationChannel = AndroidNotificationChannel(
        _androidHydrationChannelId,
        _androidHydrationChannelName,
        description: _androidHydrationChannelDesc,
        importance: Importance.defaultImportance,
      );
      final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (androidImpl != null) {
        await androidImpl.createNotificationChannel(androidChannel);
        await androidImpl.createNotificationChannel(hydrationChannel);
      }
      _initialized = true;
      debugPrint('NotificationService initialized for timezone: $timeZoneName');
    } catch (e) {
      debugPrint('NotificationService init error: $e');
    }
  }

  Future<bool> requestPermissions() async {
    try {
      final androidImpl = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      if (androidImpl != null) {
        final bool? granted = await androidImpl.requestNotificationsPermission();
        return granted ?? true; // Older Androids return null, treat as granted
      }
    } catch (e) {
      debugPrint('requestPermissions error: $e');
    }
    return true;
  }

  // Helper: convert minutes from midnight to TZDateTime today at that time in local tz.

  // Returns the next instance for a given weekday (1=Mon..7=Sun) at the provided minutes.
  tz.TZDateTime _nextInstanceForWeekday(int weekday, int minutes) {
    final now = tz.TZDateTime.now(tz.local);
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, minutes ~/ 60, minutes % 60);
    // Move to target weekday
    final int currentWeekday = scheduled.weekday; // 1..7
    int diff = weekday - currentWeekday;
    if (diff < 0) diff += 7;
    scheduled = scheduled.add(Duration(days: diff));
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 7));
    }
    return scheduled;
  }

  // Compute reminder days if not specified: spread across the week based on targetDaysPerWeek.
  List<int> _deriveReminderDays(int targetDaysPerWeek) {
    switch (targetDaysPerWeek.clamp(1, 7)) {
      case 1:
        return const [3]; // Wed
      case 2:
        return const [2, 5]; // Tue, Fri
      case 3:
        return const [1, 3, 5]; // Mon, Wed, Fri
      case 4:
        return const [1, 2, 4, 6]; // Mon, Tue, Thu, Sat
      case 5:
        return const [1, 2, 3, 4, 5]; // Weekdays
      case 6:
        return const [1, 2, 3, 4, 5, 6]; // Mon-Sat
      case 7:
      default:
        return const [1, 2, 3, 4, 5, 6, 7];
    }
  }

  int _baseIdForHabit(String habitId) => habitId.hashCode & 0x7fffffff;

  Future<void> cancelHabitReminders(String habitId) async {
    final base = _baseIdForHabit(habitId);
    // Cancel all 8 ids (0..7) to be safe
    for (int i = 0; i <= 7; i++) {
      try {
        await _plugin.cancel(base + i);
      } catch (e) {
        debugPrint('cancel error for id ${base + i}: $e');
      }
    }
  }

  Future<void> scheduleHabitReminders(Habit habit) async {
    await init();
    final time = habit.reminderTimeMinutes;
    if (time == null) {
      await cancelHabitReminders(habit.id);
      return;
    }
    await requestPermissions();
    await cancelHabitReminders(habit.id);

    final days = (habit.reminderDays == null || habit.reminderDays!.isEmpty)
        ? _deriveReminderDays(habit.targetDaysPerWeek)
        : habit.reminderDays!;

    final base = _baseIdForHabit(habit.id);

    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        _androidChannelId,
        _androidChannelName,
        channelDescription: _androidChannelDesc,
        importance: Importance.high,
        priority: Priority.high,
        category: AndroidNotificationCategory.reminder,
        icon: '@mipmap/ic_launcher',
      ),
    );

    for (final weekday in days.toSet()) {
      try {
        final scheduleTime = _nextInstanceForWeekday(weekday, time);
        await _plugin.zonedSchedule(
          base + weekday, // unique ID per weekday
          habit.name,
          'Time for your habit: ${habit.name}',
          scheduleTime,
          details,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          matchDateTimeComponents: DateTimeComponents.dayOfWeekAndTime,
          payload: habit.id,
        );
      } catch (e) {
        debugPrint('Error scheduling for weekday $weekday: $e');
      }
    }
  }

  // ===== Hydration-specific helpers =====

  int _hydrationBaseId() => 'hydration'.hashCode & 0x7fffffff;

  Future<void> cancelHydrationReminders() async {
    final base = _hydrationBaseId();
    for (int i = 0; i < 50; i++) {
      try {
        await _plugin.cancel(base + i);
      } catch (e) {
        debugPrint('cancel hydration error for id ${base + i}: $e');
      }
    }
  }

  /// Schedule hydration reminders between [startMinutes] and [endMinutes]
  /// every [intervalMinutes].
  Future<void> scheduleHydrationReminders({
    required int startMinutes,
    required int endMinutes,
    required int intervalMinutes,
  }) async {
    await init();
    await requestPermissions();
    await cancelHydrationReminders();

    if (intervalMinutes <= 0) return;
    if (endMinutes <= startMinutes) return;

    final androidDetails = AndroidNotificationDetails(
      _androidHydrationChannelId,
      _androidHydrationChannelName,
      channelDescription: _androidHydrationChannelDesc,
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      category: AndroidNotificationCategory.reminder,
      icon: '@mipmap/ic_launcher',
    );

    final details = NotificationDetails(android: androidDetails);

    final base = _hydrationBaseId();
    final now = tz.TZDateTime.now(tz.local);
    final today = tz.TZDateTime(tz.local, now.year, now.month, now.day);

    final start = today.add(Duration(
      hours: startMinutes ~/ 60,
      minutes: startMinutes % 60,
    ));
    final end = today.add(Duration(
      hours: endMinutes ~/ 60,
      minutes: endMinutes % 60,
    ));

    final messages = [
      'Take a small sip of water and reset your focus.',
      'Time to hydrate 💧 Your body and mind will thank you.',
      'Pause for a water break – a tiny ritual for a better day.',
    ];

    int index = 0;
    for (var time = start;
        time.isBefore(end) || time.isAtSameMomentAs(end);
        time = time.add(Duration(minutes: intervalMinutes))) {
      if (time.isBefore(now)) {
        continue;
      }
      final message = messages[index % messages.length];
      index++;
      try {
        await _plugin.zonedSchedule(
          base + index,
          'Time to drink water',
          message,
          time,
          details,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          matchDateTimeComponents: DateTimeComponents.time,
          payload: 'hydration',
        );
      } catch (e) {
        debugPrint('Error scheduling hydration reminder: $e');
      }
    }
  }

  // ===== Movement-specific helpers =====

  int _movementBaseId() => 'movement'.hashCode & 0x7fffffff;

  Future<void> cancelMovementReminders() async {
    final base = _movementBaseId();
    for (int i = 0; i < 50; i++) {
      try {
        await _plugin.cancel(base + i);
      } catch (e) {
        debugPrint('cancel movement error for id ${base + i}: $e');
      }
    }
  }

  Future<void> scheduleMovementReminders({
    required int startMinutes,
    required int endMinutes,
    required int intervalMinutes,
  }) async {
    await init();
    await requestPermissions();
    await cancelMovementReminders();

    if (intervalMinutes <= 0) return;
    if (endMinutes <= startMinutes) return;

    final androidDetails = AndroidNotificationDetails(
      _androidChannelId,
      _androidChannelName,
      channelDescription: _androidChannelDesc,
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      category: AndroidNotificationCategory.reminder,
      icon: '@mipmap/ic_launcher',
    );

    final details = NotificationDetails(android: androidDetails);

    final base = _movementBaseId();
    final now = tz.TZDateTime.now(tz.local);
    final today = tz.TZDateTime(tz.local, now.year, now.month, now.day);

    final start = today.add(Duration(
      hours: startMinutes ~/ 60,
      minutes: startMinutes % 60,
    ));
    final end = today.add(Duration(
      hours: endMinutes ~/ 60,
      minutes: endMinutes % 60,
    ));

    final messages = [
      'Time for a quick movement break.',
      'Stretch your legs and take a deep breath.',
      'Posture check! Move around for a bit.',
      'Gentle movement helps your mind and body.',
    ];

    int index = 0;
    for (var time = start;
        time.isBefore(end) || time.isAtSameMomentAs(end);
        time = time.add(Duration(minutes: intervalMinutes))) {
      if (time.isBefore(now)) {
        continue;
      }
      final message = messages[index % messages.length];
      index++;
      try {
        await _plugin.zonedSchedule(
          base + index,
          'Movement Break',
          message,
          time,
          details,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          matchDateTimeComponents: DateTimeComponents.time,
          payload: 'movement',
        );
      } catch (e) {
        debugPrint('Error scheduling movement reminder: $e');
      }
    }
  }

  // ===== Deep Work-specific helpers =====

  int _deepWorkBaseId() => 'deep_work'.hashCode & 0x7fffffff;

  Future<void> cancelDeepWorkReminders() async {
    final base = _deepWorkBaseId();
    for (int i = 0; i < 50; i++) {
      try {
        await _plugin.cancel(base + i);
      } catch (e) {
        debugPrint('cancel deep work error for id ${base + i}: $e');
      }
    }
  }

  Future<void> scheduleDeepWorkReminders({
    required int startMinutes,
    required int endMinutes,
    required int intervalMinutes,
    required DeepWorkProfile profile,
  }) async {
    await init();
    await requestPermissions();
    await cancelDeepWorkReminders();

    if (intervalMinutes <= 0) return;
    if (endMinutes <= startMinutes) return;

    const androidChannelId = _androidChannelId;
    const androidChannelName = _androidChannelName;
    const androidChannelDesc = _androidChannelDesc;

    final androidDetails = AndroidNotificationDetails(
      androidChannelId,
      androidChannelName,
      channelDescription: androidChannelDesc,
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      category: AndroidNotificationCategory.reminder,
      icon: '@mipmap/ic_launcher',
    );

    final details = NotificationDetails(android: androidDetails);

    final base = _deepWorkBaseId();
    final now = tz.TZDateTime.now(tz.local);
    final today = tz.TZDateTime(tz.local, now.year, now.month, now.day);

    final start = today.add(Duration(
      hours: startMinutes ~/ 60,
      minutes: startMinutes % 60,
    ));
    final end = today.add(Duration(
      hours: endMinutes ~/ 60,
      minutes: endMinutes % 60,
    ));

    String profileLabel(DeepWorkProfile p) {
      switch (p) {
        case DeepWorkProfile.deepWork:
          return 'Deep Work';
        case DeepWorkProfile.study:
          return 'Study';
        case DeepWorkProfile.creative:
          return 'Creative Focus';
        case DeepWorkProfile.lightAdmin:
          return 'Light Admin';
        case DeepWorkProfile.custom:
          return 'Focus Session';
      }
    }

    final title = '${profileLabel(profile)} session';

    final messages = [
      'Time to protect a focused block of work.',
      'Create a small island of deep focus right now.',
      'Silence distractions and commit to the next block.',
    ];

    int index = 0;
    for (var time = start;
        time.isBefore(end) || time.isAtSameMomentAs(end);
        time = time.add(Duration(minutes: intervalMinutes))) {
      if (time.isBefore(now)) {
        continue;
      }
      final message = messages[index % messages.length];
      index++;
      try {
        await _plugin.zonedSchedule(
          base + index,
          title,
          message,
          time,
          details,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          matchDateTimeComponents: DateTimeComponents.time,
          payload: 'deep_work',
        );
      } catch (e) {
        debugPrint('Error scheduling deep work reminder: $e');
      }
    }
  }

  Future<void> scheduleOneTimeTestNotificationInOneMinute() async {
    await init();
    await requestPermissions();
    final now = tz.TZDateTime.now(tz.local);
    final when = now.add(const Duration(minutes: 1));
    final id = Random().nextInt(0x7fffffff);
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        _androidChannelId,
        _androidChannelName,
        channelDescription: _androidChannelDesc,
        importance: Importance.high,
        priority: Priority.high,
        category: AndroidNotificationCategory.reminder,
        icon: '@mipmap/ic_launcher',
      ),
    );
    await _plugin.zonedSchedule(
      id,
      'Test Notification',
      'This is your Daily Reset test reminder.',
      when,
      details,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      payload: 'test',
    );
  }

  // Utility for UI formatting
  static String formatReminderTime(BuildContext context, int minutes) {
    final timeOfDay = TimeOfDay(hour: minutes ~/ 60, minute: minutes % 60);
    return MaterialLocalizations.of(context).formatTimeOfDay(timeOfDay,
        alwaysUse24HourFormat: MediaQuery.maybeOf(context)?.alwaysUse24HourFormat ?? false);
  }
}
